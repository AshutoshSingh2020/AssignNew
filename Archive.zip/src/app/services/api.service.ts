import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, Observable, tap } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  
  constructor( private http:HttpClient) { }
  sendRequest(apiEndpoint: string):Observable<any> {
    return this.http.get(apiEndpoint).pipe(tap(response => {
    }),catchError(error => {
      throw error;
    })
    );
  }
}
