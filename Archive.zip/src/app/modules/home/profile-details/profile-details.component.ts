import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';

@Component({
  selector: 'app-profile-details',
  templateUrl: './profile-details.component.html',
  styleUrls: ['./profile-details.component.scss']
})
export class ProfileDetailsComponent implements OnInit {
  loading: boolean = false;
  constructor(private apiSer: ApiService, private route: ActivatedRoute) { }
  id: string = '';
  userDetails: any = []
  panetName: string = ''
  spaciesNamestr: string = ''
  movieName: any = [];
  starshipName: any = [];
  spaciesName: any = [];
  vechilesName: any = [];
  filmName: any = '';
  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      this.id = params.get('id') || '';
      this.getDetails(this.id);
    });
  }
  getDetails(item: any) {
    this.loading = true;
    this.apiSer.sendRequest('https://swapi.dev/api/people/' + item).subscribe({
      next: (res: any) => {
        this.userDetails = res;
        if (res.homeworld) {
          this.apiSer.sendRequest(res.homeworld).subscribe({
            next: (res: any) => {
              this.panetName = res.name;
              console.log(this.panetName)
            },
            error(err) {
              console.error('Error:', err);
            },
          });
        }
        if ((res.species.length > 0)) {
          (res.species).forEach((element: string) => {
            this.apiSer.sendRequest(element).subscribe({
              next: (res: any) => {
                this.spaciesName.push(res.name);
                this.spaciesNamestr = this.spaciesName.join(',')
              },
              error(err) {
                console.error('Error:', err);
              },
            });
          });


        }
        if ((res.films.length > 0)) {
          (res.films).forEach((element: string) => {
            this.apiSer.sendRequest(element).subscribe({
              next: (res: any) => {
                this.movieName.push(res.title);
              },
              error(err) {
                console.error('Error:', err);
              },
            });
          });
        }
        if ((res.starships.length > 0)) {
          (res.starships).forEach((element: string) => {
            this.apiSer.sendRequest(element).subscribe({
              next: (res: any) => {
                this.starshipName.push(res.name);
              },
              error(err) {
                console.error('Error:', err);
              },
            });
          });
        }
        if ((res.vehicles.length > 0)) {
          (res.vehicles).forEach((element: string) => {
            this.apiSer.sendRequest(element).subscribe({
              next: (res: any) => {
                this.vechilesName.push(res.name);
              },
              error(err) {
                console.error('Error:', err);
              },
            });
          });
        }
        this.loading = false;
      },
      error(err) {
        console.error('Error:', err);
      },
    })
  }
}
