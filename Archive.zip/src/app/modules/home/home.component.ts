import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { catchError, forkJoin, lastValueFrom, map, of, startWith } from 'rxjs';
import { ApiService } from 'src/app/services/api.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  loading: boolean = false;
  constructor(private apiSer:ApiService,private router:Router) {
    
  }
  selected = 'option2';
  movieControl = new FormControl();
  speciesControl = new FormControl();
  vehicleControl = new FormControl();
  starshipControl = new FormControl();
  birthYearControl = new FormControl();
  movieFilter:any =[];
  speciesFilter:any =[];
  vehiclesFilter:any =[];
  starFilter:any =[];
  birth: string[] = ['19BBY', '112BBY', '33BBY', '41.9BBY', '19BBY', '52BBY'];
  tableColumn: any = [
    'SI No',
    'Character Name',
    'Species',
    'Birth Year'
  ];
  tableData: any[] = [];
  filterData: any[] = [];
  p: number = 1;
  itemsPerPage: number = 10
  ngOnInit(): void {
    this.getAllMovies();
    this.getAllSpecies();
    this.getAllVehicles();
    this.getAllStarShip();
    this.getAll(this.p);

    this.movieControl.valueChanges.pipe(startWith('')).subscribe(() => this.applyFilters());
    this.speciesControl.valueChanges.pipe(startWith('')).subscribe(() => this.applyFilters());
    this.vehicleControl.valueChanges.pipe(startWith('')).subscribe(() => this.applyFilters());
    this.starshipControl.valueChanges.pipe(startWith('')).subscribe(() => this.applyFilters());
    this.birthYearControl.valueChanges.pipe(startWith('[]')).subscribe(() => this.applyFilters());
  }

  applyFilters() {
    this.filterData = this.tableData.filter(item => {
      return (
        (this.movieControl.value && this.movieControl.value.length > 0  && !this.movieControl.value.includes('')
          ? this.movieControl.value.some((selectedMovie: string) =>
              item.filmDetails?.some((film: any) => film.title === selectedMovie)
            )
          : true) &&
        
        (this.speciesControl.value && this.speciesControl.value.length > 0 && !this.speciesControl.value.includes('')
          ? this.speciesControl.value.some((selectedSpecies: string) =>
              item.speciesDetails?.some((species: any) => species.name === selectedSpecies)
            )
          : true) &&
        
        (this.vehicleControl.value && this.vehicleControl.value.length > 0 && !this.vehicleControl.value.includes('')
          ? this.vehicleControl.value.some((selectedVehicle: string) =>
              item.vehicleDetails?.some((vehicle: any) => vehicle.name === selectedVehicle)
            )
          : true) &&
        
        (this.starshipControl.value && this.starshipControl.value.length > 0  && !this.starshipControl.value.includes('')
          ? this.starshipControl.value.some((selectedStarship: string) =>
              item.starshipDetails?.some((starship: any) => starship.name === selectedStarship)
            )
          : true) &&
        
        (this.birthYearControl.value && this.birthYearControl.value.length > 0 && !this.birthYearControl.value.includes('')
          ? this.birthYearControl.value.includes(item.birth_year)
          : true)
      );
    });
    this.updatePaginatedData();
  }
  
  async getAll(item?: any) {
    this.loading = true;
    const baseUrl = 'https://swapi.dev/api/people?page=';
    this.apiSer.sendRequest(baseUrl + 1).subscribe({
      next: async (res: any) => {
        const totalCount = res.count;
        const itemsPerPage = res.results.length;
        const totalPages = Math.ceil(totalCount / itemsPerPage);
        this.tableData = res.results;

        const allPagesData = await Promise.all(
          Array.from({ length: totalPages - 1 }, (_, i) => i + 2).map(async (page) => {
            return lastValueFrom(this.apiSer.sendRequest(baseUrl + page)).then((pageRes: any) => {
              return pageRes.results;
            }).catch((err) => {
              console.error(`Error fetching data for page ${page}:`, err);
              return [];
            });
          })
        );
        this.tableData = this.tableData.concat(...allPagesData.flat());
  
        await Promise.all(
          this.tableData.map(async (element: any) => {
            await lastValueFrom(this.apiSer.sendRequest(element.homeworld)).then((homeworldData) => {
              element.homeworldDetails = homeworldData;
            }).catch((err) => {
              console.error('Error fetching homeworld:', err);
            });
  
            await Promise.all(
              element.films.map(async (filmUrl: string) => {
                return lastValueFrom(this.apiSer.sendRequest(filmUrl)).then((filmData) => {
                  return filmData;
                }).catch((err) => {
                  console.error('Error fetching film:', err);
                  return null; 
                });
              })
            ).then((filmsData) => {
              element.filmDetails = filmsData.filter(film => film !== null); 
            });
  
            await Promise.all(
              element.vehicles.map(async (vehicleUrl: string) => {
                return lastValueFrom(this.apiSer.sendRequest(vehicleUrl)).then((vehicleData) => {
                  return vehicleData;
                }).catch((err) => {
                  console.error('Error fetching vehicle:', err);
                  return null;
                });
              })
            ).then((vehiclesData) => {
              element.vehicleDetails = vehiclesData.filter(vehicle => vehicle !== null);
            });
  
            await Promise.all(
              element.starships.map(async (starshipUrl: string) => {
                return lastValueFrom(this.apiSer.sendRequest(starshipUrl)).then((starshipData) => {
                  return starshipData;
                }).catch((err) => {
                  console.error('Error fetching starship:', err);
                  return null;
                });
              })
            ).then((starshipsData) => {
              element.starshipDetails = starshipsData.filter(starship => starship !== null);
            });
  
            await Promise.all(
              element.species.map(async (speciesUrl: string) => {
                return lastValueFrom(this.apiSer.sendRequest(speciesUrl)).then((speciesData) => {
                  return speciesData;
                }).catch((err) => {
                  console.error('Error fetching species:', err);
                  return null;
                });
              })
            ).then((speciesData) => {
              element.speciesDetails = speciesData.filter(species => species !== null);
            });
          })
        );
  
        this.filterData = this.tableData;
        this.updatePaginatedData();
        this.loading = false;
      },
      error: (err: any) => {
        console.error('Error fetching initial data:', err);
        this.loading = false;
      }
    });
  }
  
  getAllMovies() {
    const baseUrl = 'https://swapi.dev/api/films/';
    this.movieFilter = [];
  
    this.apiSer.sendRequest(baseUrl).subscribe({
      next: (res: any) => {

        let totalMovies = res.count;
        let itemsPerPage = res.results.length;
        let totalPages = Math.ceil(totalMovies / itemsPerPage);

        res.results.forEach((element: any) => {
          this.movieFilter.push(element.title);
        });
  
        if (totalPages > 1) {
          for (let page = 2; page <= totalPages; page++) {
            this.fetchMoviesByPage(page);
          }
        }  
      },
      error: (err) => {
        console.error('Error fetching movies:', err);
      }
    });
  }
  
  fetchMoviesByPage(page: number) {
    const url = `https://swapi.dev/api/films/?page=${page}`;
    this.apiSer.sendRequest(url).subscribe({
      next: (res: any) => {
        res.results.forEach((element: any) => {
          this.movieFilter.push(element.title);
        });
      },
      error: (err) => {
        console.error(`Error fetching movies from page ${page}:`, err);
      }
    });
  }
  getAllSpecies() {
    const baseUrl = 'https://swapi.dev/api/species/';
    this.movieFilter = [];
  
    this.apiSer.sendRequest(baseUrl).subscribe({
      next: (res: any) => {

        let totalMovies = res.count;
        let itemsPerPage = res.results.length;
        let totalPages = Math.ceil(totalMovies / itemsPerPage);

        res.results.forEach((element: any) => {
          this.speciesFilter.push(element.name);
        });
  
        if (totalPages > 1) {
          for (let page = 2; page <= totalPages; page++) {
            this.fetchSpeciesByPage(page);
          }
        }  
      },
      error: (err) => {
        console.error('Error fetching movies:', err);
      }
    });
  }
  
  fetchSpeciesByPage(page: number) {
    const url = `https://swapi.dev/api/species/?page=${page}`;
    this.apiSer.sendRequest(url).subscribe({
      next: (res: any) => {
        res.results.forEach((element: any) => {
          this.speciesFilter.push(element.name);
        });
      },
      error: (err) => {
        console.error(`Error fetching movies from page ${page}:`, err);
      }
    });
  }
  getAllVehicles() {
    const baseUrl = 'https://swapi.dev/api/vehicles/';
    this.movieFilter = [];
  
    this.apiSer.sendRequest(baseUrl).subscribe({
      next: (res: any) => {

        let totalMovies = res.count;
        let itemsPerPage = res.results.length;
        let totalPages = Math.ceil(totalMovies / itemsPerPage);

        res.results.forEach((element: any) => {
          this.vehiclesFilter.push(element.name);
        });
  
        if (totalPages > 1) {
          for (let page = 2; page <= totalPages; page++) {
            this.fetchVehiclesByPage(page);
          }
        }  
      },
      error: (err) => {
        console.error('Error fetching movies:', err);
      }
    });
  }
  
  fetchVehiclesByPage(page: number) {
    const url = `https://swapi.dev/api/vehicles/?page=${page}`;
    this.apiSer.sendRequest(url).subscribe({
      next: (res: any) => {
        res.results.forEach((element: any) => {
          this.vehiclesFilter.push(element.name);
        });
      },
      error: (err) => {
        console.error(`Error fetching movies from page ${page}:`, err);
      }
    });
  }

  getAllStarShip() {
    const baseUrl = 'https://swapi.dev/api/starships/';
    this.movieFilter = [];
  
    this.apiSer.sendRequest(baseUrl).subscribe({
      next: (res: any) => {

        let totalMovies = res.count;
        let itemsPerPage = res.results.length;
        let totalPages = Math.ceil(totalMovies / itemsPerPage);

        res.results.forEach((element: any) => {
          this.starFilter.push(element.name);
        });
  
        if (totalPages > 1) {
          for (let page = 2; page <= totalPages; page++) {
            this.fetchStarshipByPage(page);
          }
        }  
      },
      error: (err) => {
        console.error('Error fetching movies:', err);
      }
    });
  }
  
  fetchStarshipByPage(page: number) {
    const url = `https://swapi.dev/api/starships/?page=${page}`;
    this.apiSer.sendRequest(url).subscribe({
      next: (res: any) => {
        res.results.forEach((element: any) => {
          this.starFilter.push(element.name);
        });
      },
      error: (err) => {
        console.error(`Error fetching movies from page ${page}:`, err);
      }
    });
  }

  profileDetails(item:any){
    let filtered =(item.split('/')).filter(function (el:any) {
      return el != '';
    });
    // this.router.navigate(['/profile-details',filtered[filtered.length-1]])
    const url = this.router.createUrlTree(['/profile-details', filtered[filtered.length - 1]]).toString();
  window.open(url, '_blank');
  }
  pagechange(item:any){
    this.p = item;
    this.getAll(item);
  }

  paginatedData: any[] = [];
  currentPage = 1; 
  totalPages = 0;

  updatePaginatedData() {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    const endIndex = startIndex + this.itemsPerPage;
    this.paginatedData = this.filterData.slice(startIndex, endIndex);
     this.totalPages = Math.ceil(this.filterData.length / this.itemsPerPage);
     console.log(this.totalPages)
  }

  goToPage(page: number) {
    this.currentPage = page;
    this.updatePaginatedData();
  }


}
